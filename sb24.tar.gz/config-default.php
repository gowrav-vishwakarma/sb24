<?php
$config['atk']['base_path']='./atk4/';
$config['dsn']='mysql://root:winserver@localhost/sb24';

$config['url_postfix']='';
$config['url_prefix']='?page=';

$config['logger']['log_dir']='./';

$config['tmail']['transport'] = "PHPMailer";
$config['tmail']['phpmailer']['from'] = "sabkuch24@gmail.com";
$config['tmail']['from'] = "sabkuch24@gmail.com";
$config['tmail']['phpmailer']['from_name'] = "Sabkuch24 Rajsthan Local Search Engine";
$config['tmail']['smtp']['host'] = "ssl://smtp.gmail.com";
$config['tmail']['smtp']['port'] = 465;
$config['tmail']['phpmailer']['username'] = "sabkuch24@gmail.com";
$config['tmail']['phpmailer']['password'] = "9928018585";
$config['tmail']['phpmailer']['reply_to'] = "sabkuch24@gmail.com";
$config['tmail']['phpmailer']['reply_to_name'] = "Sabkuch24 Rajsthan Local Search Engine";



