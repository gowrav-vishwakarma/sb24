-- phpMyAdmin SQL Dump
-- version 3.4.5deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 09, 2013 at 03:42 PM
-- Server version: 5.1.61
-- PHP Version: 5.3.6-13ubuntu3.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sb24`
--

-- --------------------------------------------------------

--
-- Table structure for table `ad`
--

CREATE TABLE IF NOT EXISTS `ad` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adblock_id` int(11) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `valid_till` date DEFAULT NULL,
  `last_renewal_on` date DEFAULT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `mobile_number` varchar(255) DEFAULT NULL,
  `add_charge` varchar(255) DEFAULT NULL,
  `ad_image_id` int(11) DEFAULT NULL,
  `click_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_adblock_id` (`adblock_id`),
  KEY `fk_ad_image_id` (`ad_image_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=77 ;

--
-- Dumping data for table `ad`
--

INSERT INTO `ad` (`id`, `adblock_id`, `created_on`, `valid_till`, `last_renewal_on`, `company_name`, `contact_person`, `mobile_number`, `add_charge`, `ad_image_id`, `click_url`) VALUES
(1, 1, '2013-10-19', '2013-10-31', '2013-10-19', 'Accademy Career Solution', 'Gowrav', '9783807100', '100', 38, 'http://www.academycareersolution.com/'),
(3, 2, '2013-10-19', NULL, '2013-10-19', 'Test1', '', '', '', 54, ''),
(4, 2, '2013-10-19', NULL, '2013-10-19', '', '', '', '', 56, ''),
(5, 3, '2013-10-19', NULL, '2013-10-19', '', '', '', '', 58, ''),
(6, 3, '2013-10-19', NULL, '2013-10-19', '', '', '', '', 60, ''),
(7, 4, '2013-10-22', NULL, '2013-10-22', '', '', '', '', 62, ''),
(8, 1, '2013-10-24', NULL, '2013-10-24', '', '', '', '', 46, ''),
(9, 4, '2013-10-26', NULL, '2013-10-26', '', '', '', '', 64, ''),
(10, 5, '2013-10-26', NULL, '2013-10-26', '', '', '', '', 66, ''),
(11, 5, '2013-10-26', NULL, '2013-10-26', '', '', '', '', 68, ''),
(12, 1, '2013-10-31', NULL, '2013-10-31', '', '', '', '', 140, ''),
(13, 1, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 152, ''),
(14, 1, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 154, ''),
(15, 1, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 156, ''),
(16, 1, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 160, ''),
(17, 1, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 158, ''),
(18, 1, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 162, ''),
(19, 1, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 164, ''),
(20, 1, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 166, ''),
(21, 1, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 168, ''),
(22, 1, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 170, ''),
(23, 1, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 172, ''),
(24, 1, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 174, ''),
(25, 1, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 176, ''),
(26, 2, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 178, ''),
(27, 2, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 180, ''),
(28, 2, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 182, ''),
(29, 2, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 184, ''),
(30, 2, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 186, ''),
(31, 2, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 188, ''),
(32, 2, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 192, ''),
(33, 2, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 196, ''),
(34, 2, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 198, ''),
(35, 3, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 200, ''),
(36, 3, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 202, ''),
(37, 3, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 204, ''),
(38, 3, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 206, ''),
(39, 3, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 208, ''),
(40, 3, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 210, ''),
(41, 3, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 212, ''),
(42, 3, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 214, ''),
(43, 3, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 216, ''),
(44, 3, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 218, ''),
(45, 4, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 220, ''),
(46, 4, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 222, ''),
(47, 4, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 224, ''),
(48, 4, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 228, ''),
(49, 4, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 230, ''),
(50, 4, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 232, ''),
(51, 4, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 234, ''),
(52, 4, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 236, ''),
(53, 5, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 238, ''),
(54, 5, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 240, ''),
(55, 5, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 242, ''),
(56, 5, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 244, ''),
(57, 5, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 246, ''),
(58, 5, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 248, ''),
(59, 5, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 250, ''),
(60, 5, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 252, ''),
(61, 6, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 254, ''),
(62, 7, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 256, ''),
(63, 8, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 260, ''),
(64, 9, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 262, ''),
(65, 10, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 264, ''),
(66, 11, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 266, ''),
(67, 12, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 268, ''),
(68, 13, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 270, ''),
(69, 14, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 272, ''),
(70, 15, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 274, ''),
(71, 16, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 276, ''),
(72, 17, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 278, ''),
(73, 18, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 280, ''),
(74, 19, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 282, ''),
(75, 20, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 284, ''),
(76, 21, '2013-11-02', NULL, '2013-11-02', '', '', '', '', 286, '');

-- --------------------------------------------------------

--
-- Table structure for table `adblock`
--

CREATE TABLE IF NOT EXISTS `adblock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `order` varchar(255) DEFAULT NULL,
  `rotation_time` varchar(255) DEFAULT NULL,
  `position` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `height` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `adblock`
--

INSERT INTO `adblock` (`id`, `name`, `order`, `rotation_time`, `position`, `is_active`, `height`) VALUES
(1, 'Top Add Block', '1', '20', 'Top', 1, '100'),
(2, 'Left Block 1', '1', '20', 'Left', 1, '202'),
(3, 'Left Block 2', '2', '20', 'Right', 1, '202'),
(4, 'Right Block 1', '2', '20', 'Left', 1, '202'),
(5, 'Right Block2', '1', '20', 'Right', 1, '202'),
(6, 'Left Block 3', '3', '20', 'Left', 1, '202'),
(7, 'Left Block 4', '4', '20', 'Left', 1, '202'),
(8, 'Left Block 5', '5', '20', 'Left', 1, '202'),
(9, 'Left Block 6', '6', '20', 'Left', 1, '202'),
(10, 'Left Block 7', '7', '20', 'Left', 1, '202'),
(11, 'Left Block 8', '8', '20', 'Left', 1, '202'),
(12, 'Left Block 10', '10', '20', 'Left', 1, '202'),
(13, 'Left Block 9', '9', '20', 'Left', 1, '202'),
(14, 'Right Block 3', '3', '20', 'Right', 1, '202'),
(15, 'Right Block 4', '4', '20', 'Right', 1, '202'),
(16, 'Right Block 5', '5', '20', 'Right', 1, '202'),
(17, 'Right Block 6', '6', '20', 'Right', 1, '202'),
(18, 'Right Block 7', '7', '20', 'Right', 1, '202'),
(19, 'Right Block 8', '8', '20', 'Right', 1, '202'),
(20, 'Right Block 9', '9', '20', 'Right', 1, '202'),
(21, 'Right Block 10', '10', '20', 'Right', 1, '202');

-- --------------------------------------------------------

--
-- Table structure for table `adpayment`
--

CREATE TABLE IF NOT EXISTS `adpayment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `ad_id` int(11) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `received_on` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_staff_id` (`staff_id`),
  KEY `fk_ad_id` (`ad_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
