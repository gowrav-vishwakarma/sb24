sb24
====

TODO:

member:	
		- tehsil and area from its corresponding listing as well as its joining date
		- clear religion and casts to be filled by client at all
		- beforeDelete hooks in religion=>cast=>subcast

businessdirectoyr:
		- businesscategory add hook beforeDelete for Industry => Segment => listing
		- add new listing form .. define MORE STEPS


distance:
		- by bus instead by train

ALL using IMAGES ... beforeDelete remove images to save space


=================

Contact us in business directory more .. email send
editor in chrome ..=> member area =>business listing edit=>about us
senitize all $_GET inputs to prevent sql injections on all pages