<?php
class Exception_Filestore_Physical extends Exception_Filestore{}
