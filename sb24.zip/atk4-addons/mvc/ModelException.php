<?php
/**
 * Created on 06.01.2008 by *Camper* (camper@adevel.com)
 */
class ModelException extends BaseException{}
