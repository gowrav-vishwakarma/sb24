<?php
namespace dynamic_model;
class Controller_AutoCreator extends Controller_AutoCreator_MySQL
{
}
