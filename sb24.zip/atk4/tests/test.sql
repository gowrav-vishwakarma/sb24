create table book (id int not null primary key auto_increment, name varchar(255));
