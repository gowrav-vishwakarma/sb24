<?php
$config['atk']['base_path']='../';
$config['url_postfix']='';
$config['url_prefix']='?page=';
$config['logger']['log_output']='full';
$config['mongo']['db']='test';
