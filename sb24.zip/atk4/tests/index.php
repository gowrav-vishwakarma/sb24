<?php
include '../loader.php';
$api=new TestApi('sample_project');
$api->main();
?>
