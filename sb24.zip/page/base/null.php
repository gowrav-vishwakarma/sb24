<?php

class page_base_null extends Page {}