<?php

class page_admin_filestore extends filestore\Page_FileAdmin {
	function init(){
		parent::init();

	}
}