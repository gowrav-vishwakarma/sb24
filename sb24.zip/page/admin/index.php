<?php

class page_admin_index extends page_base_admin {
	function init(){
		parent::init();

		// $this->add('businessdirectory/View_Summary');

	}
}