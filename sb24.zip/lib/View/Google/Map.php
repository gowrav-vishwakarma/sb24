<?php
class View_Google_Map extends View_Map{
	function defaultTemplate(){
		
	}	
}