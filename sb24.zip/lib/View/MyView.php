<?php
class View_MyView extends View{



function defaultTemplat(){
	return array('view/myview');
}
}
