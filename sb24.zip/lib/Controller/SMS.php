<?php

class Controller_SMS extends AbstractController{
	function sendActivationCode($model,$code){

	}

	function sendSMS($no,$msg){}
}