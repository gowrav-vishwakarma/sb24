<?php

class page_maps_page_search extends page_base_site {
	function init(){
		parent::init();

	}
}