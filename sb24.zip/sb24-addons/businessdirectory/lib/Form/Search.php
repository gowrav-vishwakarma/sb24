<?php

namespace businessdirectory;

class Form_Search extends \Form{
	
}