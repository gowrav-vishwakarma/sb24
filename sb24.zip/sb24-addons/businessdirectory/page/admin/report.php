<?php

class page_businessdirectory_page_admin_report extends Page {
	function init(){
		parent::init();

	}
}