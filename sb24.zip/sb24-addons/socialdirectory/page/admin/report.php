<?php
class page_socialdirectory_page_admin_report extends page_base_admin {
	function init(){
		parent::init();

	}
}