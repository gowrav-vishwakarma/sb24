<?php

class page_jobandvacancy_page_admin_report extends page_base_admin {
	function init(){
		parent::init();

	}
}