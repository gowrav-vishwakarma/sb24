<?php

class page_memberpanel_page_dashboard extends page_memberpanel_page_base {
	function init(){
		parent::init();

		

	}
}